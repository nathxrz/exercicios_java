package model;

public enum Cidade {
    Pelotas, Porto_Alegre;
}
