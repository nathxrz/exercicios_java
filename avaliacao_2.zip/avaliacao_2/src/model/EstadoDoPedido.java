package model;

public enum EstadoDoPedido {
    Aberto, Faturado, Em_Transporte, Entregue;
}
