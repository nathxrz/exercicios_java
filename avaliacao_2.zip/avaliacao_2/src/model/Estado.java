package model;

public enum Estado {
    RS;
}
